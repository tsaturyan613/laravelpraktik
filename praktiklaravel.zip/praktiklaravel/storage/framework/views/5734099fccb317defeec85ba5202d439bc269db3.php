<h1>Test</h1>
<?php /**PATH C:\xampp\htdocs\praktiklaravel\resources\views/mail-body.blade.php ENDPATH**/ ?>