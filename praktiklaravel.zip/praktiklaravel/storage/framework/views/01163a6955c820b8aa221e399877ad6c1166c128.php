<form action="<?php echo e(route('dispatch.email')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="email">
    <button>Send Email</button>
</form>
<?php /**PATH C:\xampp\htdocs\praktiklaravel\resources\views/welcome.blade.php ENDPATH**/ ?>