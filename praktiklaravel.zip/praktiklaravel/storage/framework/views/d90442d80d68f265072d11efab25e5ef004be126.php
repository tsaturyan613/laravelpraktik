<form action="<?php echo e(route('add.name')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="name">
    <button>ADD</button>
</form>
<?php /**PATH C:\xampp\htdocs\praktiklaravel\resources\views/name.blade.php ENDPATH**/ ?>