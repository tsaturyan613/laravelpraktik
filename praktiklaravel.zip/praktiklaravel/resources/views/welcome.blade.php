<form action="{{route('dispatch.email')}}" method="post">
    @csrf
    <input type="text" name="email">
    <button>Send Email</button>
</form>
