<form action="{{ route('add.name') }}" method="post">
    @csrf
    <input type="text" name="name">
    <button>ADD</button>
</form>
