<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::post('/send-mail',function (Request $request){
    \App\Jobs\MailerJob::dispatch($request->email)->delay(\Illuminate\Support\Carbon::now()->addMinute())->onQueue('mail');
    die('123');
    return redirect()->back();
})->name('dispatch.email');

Route::view('/name','name');

Route::post('/add-name', function (Request $request) {
    \App\Jobs\InsertName::dispatch($request->name)->delay(\Illuminate\Support\Carbon::now()->addMinute())->onQueue('name');
    return redirect()->back();
})->name('add.name');
